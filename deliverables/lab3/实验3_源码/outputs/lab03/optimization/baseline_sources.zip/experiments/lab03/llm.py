"""LLM scores candidate actions, never supplies answer IDs or creates graph edges.

Default local backend is Qwen2.5-0.5B-Instruct, pinned to a published revision.
Remote Responses API is optional and uses LAB03_LLM_* environment variables.
No Codex credentials are read by this application.
"""
from __future__ import annotations
import hashlib,json,math,os,time,urllib.request
from pathlib import Path
from .domain import expert_legal,digest,State,RELATIONS,path_key
MODEL_ID='Qwen/Qwen2.5-0.5B-Instruct'
REVISION='7ae557604adf67be50417f59c2c2f167def9a775'
_runtime=None
SCORE_PROTOCOL = 'path-prefix-value-and-evidence-v3'
WEIGHTS_SHA256 = 'fdf756fa7fcbe7404d5c60e26bff1a0c8b8aa1f72ced49e7dd0210fe288fb7fe'
EVIDENCE_POLICY = ('The entire prefix is eligible iff every edge has verified=True AND active=True '
                   'AND confidence>=0.55. Evaluate evidence eligibility independently of path reward '
                   'and endpoint relevance; no model judgment overrides the deterministic expert rules.')


def legality_prompt_for(prompt):
    """One evidence policy for both providers; no precomputed eligibility label."""
    facts = prompt.split('Candidate:', 1)
    if len(facts) != 2:
        raise ValueError('合法性评估缺少候选路径事实')
    return ('Assess only evidence eligibility, not the target answer. ' + EVIDENCE_POLICY +
            '\nReturn Y for eligible, N for ineligible.\n' +
            facts[1].split('Choose only', 1)[0] + '\nEligibility Y/N:')


def verified_local_source():
    """Never label arbitrary LAB03_LOCAL_MODEL weights as the pinned Qwen model."""
    configured = os.environ.get('LAB03_LOCAL_MODEL')
    local = Path(configured or str(Path.home()/'.cache/lab03-models/Qwen2.5-0.5B-Instruct'))
    if not (local/'model.safetensors').is_file():
        if configured:
            raise ValueError('LAB03_LOCAL_MODEL未指向完整的固定版本Qwen权重目录')
        from huggingface_hub import snapshot_download
        local = Path(snapshot_download(MODEL_ID, revision=REVISION, local_files_only=True))
    with (local/'model.safetensors').open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    if actual != WEIGHTS_SHA256:
        raise ValueError('本地模型权重与固定Qwen版本不一致，拒绝错误标注模型身份；请运行scripts/prepare_lab03_model.py')
    return str(local.resolve())


def candidate_actions(graph, query, limit=8, max_depth=2):
    """Bounded breadth-first look-ahead; never consults goal labels or an oracle."""
    if type(limit) is not int or not 1 <= limit <= 64 or type(max_depth) is not int or not 1 <= max_depth <= query.hops:
        raise ValueError('LLM前瞻范围不合法')
    todo = [State((query.start,))]
    candidates = []
    while todo and len(candidates) < limit:
        state = todo.pop(0)
        for edge in graph.successors(state, query, False):
            candidates.append((state, edge))
            if state.depth + 1 < max_depth:
                todo.append(graph.apply(state, edge))
            if len(candidates) == limit:
                break
    return candidates


def prompt_for(graph, query, edge, state=None):
    state = State((query.start,)) if state is None else state
    if not graph.valid_prefix(state, query, expert=False) or edge not in graph.successors(state, query, False):
        raise ValueError('候选动作必须绑定当前问题的合法结构前缀')
    prefix = graph.apply(state, edge)
    a, b = graph.nodes[edge.source], graph.nodes[edge.target]
    evidence = [graph.edges[e] for e in prefix.edges]
    history = [dict(step=i + 1, source_kind=graph.nodes[e.source].kind,
                    source_sector=graph.nodes[e.source].sector, relation=e.relation,
                    target_kind=graph.nodes[e.target].kind, target_sector=graph.nodes[e.target].sector,
                    target_listed=graph.nodes[e.target].listed, confidence=e.confidence,
                    verified=e.verified, active=e.active) for i, e in enumerate(evidence)]
    return ('You evaluate one candidate PATH PREFIX in a synthetic corporate knowledge graph. Do NOT answer the question or name any answer entity. '
            'Only rate the potential reward of continuing this path. A = promising and evidenced; B = uncertain; C = unsafe or poor.\n'
            f'Required relation sequence: {" then ".join(query.relations)}. Desired endpoint: Company in sector {query.sector}, listed={query.listed}.\n'
            f'Completed steps after action: {prefix.depth}/{query.hops}; remaining relations: {list(query.relations[prefix.depth:])}.\n'
            f'Path prefix facts (not a proposed answer): {json.dumps(history, ensure_ascii=False)}.\n'
            f'Candidate: {a.kind} ({a.sector}) --{edge.relation}--> {b.kind} ({b.sector}); '
            f'target listed={b.listed}; confidence={edge.confidence}; verified={edge.verified}; active={edge.active}. '
            f'Prefix verified={all(e.verified for e in evidence)}; active={all(e.active for e in evidence)}; '
            f'minimum confidence={min(e.confidence for e in evidence)}.\n'
            'Choose only A, B or C. Rating:')


def local_runtime():
    global _runtime
    if _runtime is None:
        source = verified_local_source()
        import torch
        from transformers import AutoTokenizer,AutoModelForCausalLM
        torch.set_num_threads(min(6,os.cpu_count() or 2))
        tok=AutoTokenizer.from_pretrained(source,revision=REVISION,local_files_only=True)
        model=AutoModelForCausalLM.from_pretrained(source,revision=REVISION,local_files_only=True,dtype=torch.float32)
        model.eval();_runtime=(tok,model)
    return _runtime


def local_score(prompt):
    import torch
    tok,model=local_runtime()
    started=time.perf_counter()
    def predict(text,letters):
        chat=tok.apply_chat_template([{'role':'user','content':text}],tokenize=False,add_generation_prompt=True)
        tokens=tok(chat,return_tensors='pt')
        with torch.inference_mode():
            logits=model(**tokens).logits[0,-1]
            encoded=[tok.encode(s,add_special_tokens=False) for s in letters]
            if any(len(ids) != 1 for ids in encoded) or len({ids[0] for ids in encoded}) != len(letters):
                raise ValueError('受限评分选项必须对应互不相同的单个token')
            ids=[ids[0] for ids in encoded]
            ps=torch.softmax(logits[ids],dim=0).tolist()
        return ps,tokens['input_ids'].shape[1]
    ps,n=predict(prompt,['A','B','C'])
    legality_prompt=legality_prompt_for(prompt)
    lp,ln=predict(legality_prompt,['Y','N'])
    return {'score':ps[0]+.5*ps[1],'legal_confidence':lp[0],'legal':lp[0]>=lp[1],
            'probabilities':dict(zip(['A','B','C'],ps)),'legality_probabilities':dict(zip(['Y','N'],lp)),
            'legality_prompt':legality_prompt,'label':max(zip(ps,['A','B','C']))[1],
            'backend':'local','model':MODEL_ID,'revision':REVISION,'weights_sha256':WEIGHTS_SHA256,'prompt_tokens':n+ln,
            'inference_ms':(time.perf_counter()-started)*1000,'protocol':SCORE_PROTOCOL}


def remote_score(prompt):
    key=os.environ.get('LAB03_LLM_API_KEY','');model=os.environ.get('LAB03_LLM_MODEL','')
    base=os.environ.get('LAB03_LLM_BASE_URL','https://api.openai.com/v1').rstrip('/')
    if not key or not model:raise ValueError('请配置LAB03_LLM_API_KEY和LAB03_LLM_MODEL')
    schema={'type':'object','properties':{'score':{'type':'number','minimum':0,'maximum':1},'legal':{'type':'boolean'},'reason':{'type':'string','enum':['promising','uncertain','unsafe']}},'required':['score','legal','reason'],'additionalProperties':False}
    instructions=('You only evaluate a candidate search PATH PREFIX. Never provide an answer entity or fabricate an edge. '
                  + EVIDENCE_POLICY + ' Return legal=true only when the entire prefix meets this policy. '
                  'Return score in [0,1] for continuation reward (A/promising=1, B/uncertain=0.5, C/unsafe=0). '
                  'Return reason as promising, uncertain, or unsafe; no free text or answer field. '
                  'Use the JSON schema, not a single-letter response.')
    remote_prompt=prompt.replace('Choose only A, B or C. Rating:',
                                 'Return only score, legal and reason using the required JSON schema.')
    payload={'model':model,'instructions':instructions,'input':remote_prompt,
             'text':{'format':{'type':'json_schema','name':'node_evaluation','strict':True,'schema':schema}},'store':False,'max_output_tokens':250}
    req=urllib.request.Request(base+'/responses',data=json.dumps(payload).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    start=time.perf_counter()
    with urllib.request.urlopen(req,timeout=18) as r:data=json.load(r)
    if not isinstance(data, dict) or not isinstance(data.get('output'), list):
        raise ValueError('LLM响应格式不合法')
    if data.get('status') not in (None, 'completed') or data.get('error') or data.get('incomplete_details'):
        raise ValueError('LLM响应未完成或包含错误，不能用于搜索评分')
    texts=[]
    try:
        for item in data['output']:
            if item.get('status') not in (None, 'completed'):
                raise ValueError('LLM消息未完成，不能用于搜索评分')
            for content in item.get('content', []):
                if content.get('type') == 'refusal':
                    raise ValueError('LLM拒绝评估，不能把拒绝当作有效分数')
                if content.get('type') == 'output_text':
                    if not isinstance(content.get('text'), str):
                        raise ValueError('LLM评分文本不合法')
                    texts.append(content['text'])
    except (AttributeError, TypeError) as exc:
        raise ValueError('LLM响应内容不合法') from exc
    if len(texts) != 1:
        raise ValueError('LLM必须返回唯一的结构化评估，不接受缺失或多个评估')
    value=json.loads(texts[0])
    if (not isinstance(value, dict) or set(value) != set(schema['required'])
            or type(value['legal']) is not bool or value['reason'] not in ['promising', 'uncertain', 'unsafe']):
        raise ValueError('LLM输出结构不合法；不得返回答案实体或自由文本')
    if type(value['score']) not in (int,float) or not math.isfinite(value['score']) or not 0<=value['score']<=1:raise ValueError('LLM评分越界')
    return {**value,'backend':'remote','model':data.get('model',model),'usage':data.get('usage'),
            'inference_ms':(time.perf_counter()-start)*1000,'protocol':SCORE_PROTOCOL,
            'instructions':instructions,'request_prompt':remote_prompt}


def score_actions(graph, query, candidates, backend='local'):
    if backend not in {'local', 'remote'}:
        raise ValueError('未知LLM后端')
    out = []
    for state, edge in candidates:
        prompt = prompt_for(graph, query, edge, state)
        prefix = graph.apply(state, edge)
        result = remote_score(prompt) if backend == 'remote' else local_score(prompt)
        if (type(result.get('score')) not in (int, float) or not math.isfinite(result['score'])
                or not 0 <= result['score'] <= 1 or type(result.get('legal')) is not bool):
            raise ValueError('LLM候选评分不合法')
        out.append({'edge_id': edge.id, 'path_edges': list(prefix.edges), 'parent_edges': list(state.edges),
                    'path_key': path_key(prefix.edges), 'prompt': prompt, 'prompt_sha256': digest(prompt),
                    'expert_legal': all(expert_legal(graph.edges[e]) for e in prefix.edges), **result})
    return out


def bound_scores(records):
    return {r['path_key']: r['score'] if r['legal'] else .25 * r['score'] for r in records}


def path_explanation(graph, query, result):
    """Only verified triples determine the authoritative explanation."""
    try:
        state = State(tuple(result['path']), tuple(result['edge_ids']))
    except (KeyError, TypeError):
        return ''
    if not result.get('valid') or not graph.valid_path(state, query):
        return ''
    sentences = [f'第{i + 1}跳：{graph.nodes[e.source].name}通过{RELATIONS[e.relation]}关系连接{graph.nodes[e.target].name}。'
                 for i, e in enumerate(graph.edges[eid] for eid in state.edges)]
    sentences.append(f'该证据链满足{query.hops}跳关系顺序，终点为{query.sector}行业的'
                     f'{"上市" if query.listed else "非上市"}公司；全部边均已核验、有效且置信度不低于0.55。')
    return ''.join(sentences)


def audit_explanation(graph, query, result, text):
    verified = path_explanation(graph, query, result)
    text = text if isinstance(text, str) else ''
    # Merely mentioning every entity does not establish the claimed relations.
    # Only the fully evidence-rendered text is automatically certified; other prose
    # remains visible as unverified model output, never as new graph evidence.
    return {'grounded': bool(verified and isinstance(text, str) and text.strip() == verified),
            'verified_text': verified, 'verification': 'exact evidence-rendered text only; free-form prose is not certified',
            'missing_path_entities': [graph.nodes[n].name for n in result.get('path', [])
                                      if n in graph.nodes and graph.nodes[n].name not in text]}


def explain_verified_path(graph,query,result):
    """Natural-language explanation generation happens after search; never yields its answer."""
    verified = path_explanation(graph, query, result)
    if not verified:return {'text':'未找到通过证据约束的有效路径，不生成结论解释。','generated':False,'grounded':False,'verified_text':''}
    import torch
    tok,model=local_runtime()
    chain='; '.join(f'{graph.nodes[graph.edges[e].source].name} --{graph.edges[e].relation}--> {graph.nodes[graph.edges[e].target].name}' for e in result['edge_ids'])
    prompt='请只用中文解释下面已经由程序找到并核验的图谱路径，不新增实体或关系，不作法律判断。两句话以内。已核验路径：'+chain+'。说明它满足指定的关系顺序，且只是教学证据线索。'
    text=tok.apply_chat_template([{'role':'user','content':prompt}],tokenize=False,add_generation_prompt=True)
    inp=tok(text,return_tensors='pt');start=time.perf_counter()
    with torch.inference_mode():out=model.generate(**inp,max_new_tokens=110,do_sample=False,pad_token_id=tok.eos_token_id)
    reply=tok.decode(out[0,inp['input_ids'].shape[1]:],skip_special_tokens=True)
    return {'text':reply,'generated':True,'model':MODEL_ID,'revision':REVISION,'weights_sha256':WEIGHTS_SHA256,'prompt':prompt,
            'inference_ms':(time.perf_counter()-start)*1000,
            **audit_explanation(graph, query, result, reply),
            'graph_sha256':digest(graph.to_dict()),'query_sha256':digest(query.__dict__),
            'edge_ids':result['edge_ids'],
            'note':'模型解释可能不准确；有效答案及路径由搜索程序确定，以原始关系为准。'}